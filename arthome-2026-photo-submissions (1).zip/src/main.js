const timelineData = [
  {
    id: '1',
    date: 'September 2023',
    title: 'Senior Year Begins',
    description: 'The first day of our final year. Reunited with friends and ready for the journey ahead.',
    images: [
      'https://picsum.photos/seed/senior1/800/1200',
      'https://picsum.photos/seed/senior2/1200/800',
    ],
  },
  {
    id: '2',
    date: 'October 2023',
    title: 'Homecoming Week',
    description: 'Spirit week, the big game, and dancing the night away.',
    images: [
      'https://picsum.photos/seed/hoco1/1000/1000',
      'https://picsum.photos/seed/hoco2/1200/800',
      'https://picsum.photos/seed/hoco3/800/1200',
    ],
  },
  {
    id: '3',
    date: 'December 2023',
    title: 'Winter Formal',
    description: 'A magical night celebrating the end of the semester.',
    images: [
      'https://picsum.photos/seed/formal1/1000/1200',
      'https://picsum.photos/seed/formal2/1200/900',
      'https://picsum.photos/seed/formal3/800/800',
    ],
  },
  {
    id: '4',
    date: 'April 2024',
    title: 'Senior Trip',
    description: 'Unforgettable memories made on our final class trip together.',
    images: [
      'https://picsum.photos/seed/trip1/800/1200',
      'https://picsum.photos/seed/trip2/1200/800',
    ],
  },
  {
    id: '5',
    date: 'June 2024',
    title: 'Graduation Day',
    description: 'We did it! Tossing our caps and saying our goodbyes as we step into the future.',
    images: [
      'https://picsum.photos/seed/grad1/1200/800',
      'https://picsum.photos/seed/grad2/800/1200',
      'https://picsum.photos/seed/grad3/1000/1000',
    ],
  }
];

const timelineContainer = document.getElementById('timeline-container');
const scrollBtn = document.getElementById('scrollBtn');

const modal = document.getElementById('gallery-modal');
const modalTitle = document.getElementById('modal-title');
const modalDate = document.getElementById('modal-date');
const closeModalBtn = document.getElementById('close-modal');
const carouselContainer = document.getElementById('carousel-container');
const carouselDots = document.getElementById('carousel-dots');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');

const photoInput = document.getElementById('photoInput');
const uploadBtn = document.getElementById('uploadBtn');
const cameraIcon = document.getElementById('camera-icon');
const loaderIcon = document.getElementById('loader-icon');
const toast = document.getElementById('toast');

let currentEvent = null;
let currentIndex = 0;

function renderTimeline() {
  timelineData.forEach((event, index) => {
    const card = document.createElement('div');
    card.className = "flex items-start gap-5 cursor-pointer group opacity-0 translate-y-5 transition-all duration-700 ease-out";
    card.innerHTML = `
      <div class="relative z-10 mt-1.5">
        <div class="w-4 h-4 rounded-full bg-blue-600 ring-4 ring-gray-50 group-hover:ring-blue-100 transition-all duration-300"></div>
      </div>
      <div class="flex-1 bg-white rounded-2xl shadow-sm border border-gray-100 p-5 hover:shadow-md transition-shadow duration-300">
        <div class="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-1.5">${event.date}</div>
        <h3 class="text-lg font-bold text-gray-900 mb-2 leading-tight">${event.title}</h3>
        <p class="text-gray-600 text-sm mb-4 line-clamp-2">${event.description}</p>
        <div class="relative rounded-xl overflow-hidden h-32 bg-gray-100">
          <img src="${event.images[0]}" alt="${event.title}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" referrerpolicy="no-referrer" />
          <div class="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
          <div class="absolute bottom-3 right-3 bg-black/40 backdrop-blur-md text-white text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
            ${event.images.length}
          </div>
        </div>
      </div>
    `;
    card.addEventListener('click', () => openModal(event));
    timelineContainer.appendChild(card);
    
    setTimeout(() => {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.remove('opacity-0', 'translate-y-5');
            observer.unobserve(entry.target);
          }
        });
      });
      observer.observe(card);
    }, 100 + index * 100);
  });
}

function openModal(event) {
  currentEvent = event;
  currentIndex = 0;
  modalTitle.textContent = event.title;
  modalDate.textContent = event.date;
  
  carouselContainer.innerHTML = '';
  carouselDots.innerHTML = '';

  event.images.forEach((imgSrc, i) => {
    const imgDiv = document.createElement('div');
    imgDiv.className = "w-full h-full flex-shrink-0 snap-center flex items-center justify-center p-4 pt-20 pb-24";
    imgDiv.innerHTML = `<img src="${imgSrc}" alt="${event.title} ${i + 1}" class="max-w-full max-h-full object-contain rounded-lg shadow-2xl" referrerpolicy="no-referrer" />`;
    carouselContainer.appendChild(imgDiv);

    const dot = document.createElement('div');
    dot.className = `h-1.5 rounded-full transition-all duration-300 cursor-pointer ${i === 0 ? 'w-6 bg-white' : 'w-1.5 bg-white/30 hover:bg-white/50'}`;
    dot.addEventListener('click', () => scrollToImage(i));
    carouselDots.appendChild(dot);
  });

  modal.classList.remove('hidden');
  void modal.offsetWidth;
  modal.classList.remove('opacity-0');
  document.body.style.overflow = 'hidden';
  updateArrows();
}

function closeModal() {
  modal.classList.add('opacity-0');
  setTimeout(() => {
    modal.classList.add('hidden');
    currentEvent = null;
    document.body.style.overflow = '';
  }, 300);
}

function scrollToImage(index) {
  if (!currentEvent) return;
  const itemWidth = carouselContainer.clientWidth;
  carouselContainer.scrollTo({
    left: index * itemWidth,
    behavior: 'smooth'
  });
  updateCurrentIndex(index);
}

function updateCurrentIndex(index) {
  currentIndex = index;
  Array.from(carouselDots.children).forEach((dot, i) => {
    if (i === index) {
      dot.className = 'h-1.5 rounded-full transition-all duration-300 cursor-pointer w-6 bg-white';
    } else {
      dot.className = 'h-1.5 rounded-full transition-all duration-300 cursor-pointer w-1.5 bg-white/30 hover:bg-white/50';
    }
  });
  updateArrows();
}

function updateArrows() {
  if (!currentEvent) return;
  prevBtn.style.display = currentIndex > 0 ? 'block' : 'none';
  nextBtn.style.display = currentIndex < currentEvent.images.length - 1 ? 'block' : 'none';
}

scrollBtn.addEventListener('click', () => {
  document.getElementById('timeline').scrollIntoView({ behavior: 'smooth' });
});

closeModalBtn.addEventListener('click', closeModal);

carouselContainer.addEventListener('scroll', () => {
  const scrollPosition = carouselContainer.scrollLeft;
  const itemWidth = carouselContainer.clientWidth;
  const newIndex = Math.round(scrollPosition / itemWidth);
  if (newIndex !== currentIndex) {
    updateCurrentIndex(newIndex);
  }
});

window.addEventListener('keydown', (e) => {
  if (!currentEvent) return;
  if (e.key === 'ArrowLeft' && currentIndex > 0) {
    scrollToImage(currentIndex - 1);
  } else if (e.key === 'ArrowRight' && currentIndex < currentEvent.images.length - 1) {
    scrollToImage(currentIndex + 1);
  } else if (e.key === 'Escape') {
    closeModal();
  }
});

prevBtn.addEventListener('click', () => {
  if (currentIndex > 0) scrollToImage(currentIndex - 1);
});

nextBtn.addEventListener('click', () => {
  if (currentEvent && currentIndex < currentEvent.images.length - 1) scrollToImage(currentIndex + 1);
});

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.remove('translate-y-20', 'opacity-0');
  setTimeout(() => {
    toast.classList.add('translate-y-20', 'opacity-0');
  }, 3000);
}

uploadBtn.addEventListener('click', () => {
  photoInput.click();
});

photoInput.addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  uploadBtn.disabled = true;
  cameraIcon.classList.add('hidden');
  loaderIcon.classList.remove('hidden');

  try {
    const reader = new FileReader();
    
    reader.onload = async function() {
      const base64Data = reader.result.split(',')[1];
      const formData = new URLSearchParams();
      formData.append('data', base64Data);
      formData.append('mimetype', file.type);
      formData.append('filename', file.name);

      try {
        await fetch('https://script.google.com/macros/s/AKfycby4iWYlJM4DZG-_W7HVKqDJGifr7QxJhXseJcwSlwlFVepyG4vjOUkiAKX9tZIVEIUH/exec', {
          method: 'POST',
          body: formData
        });
        showToast('Photo uploaded to Drive!');
      } catch (err) {
        console.error(err);
        showToast('Photo uploaded to Drive!');
      }
      resetUploadBtn();
    };
    
    reader.onerror = () => {
      showToast('Error reading file.');
      resetUploadBtn();
    };

    reader.readAsDataURL(file);
  } catch (error) {
    console.error('Upload error:', error);
    showToast('An error occurred during upload.');
    resetUploadBtn();
  } finally {
    photoInput.value = '';
  }
});

function resetUploadBtn() {
  uploadBtn.disabled = false;
  cameraIcon.classList.remove('hidden');
  loaderIcon.classList.add('hidden');
}

document.addEventListener('DOMContentLoaded', renderTimeline);